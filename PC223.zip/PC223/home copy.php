<?php
session_start();

$host = 'localhost'; // Database host
$dbname = 'projects'; // Database name
$username = 'root'; // Database username
$password = ''; // Database password

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Handle Login
if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM signup WHERE email = :email");
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['email'] = $user['email'];
        echo "<script>alert('Login successful!'); window.location.href='main.html';</script>";
    } else {
        echo "<script>alert('Invalid email or password.');</script>";
    }
}

// Handle Sign Up
if (isset($_POST['signup'])) {
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $phone_number = $_POST['phone_number'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    if (empty($first_name) || empty($last_name) || empty($phone_number) || empty($email) || empty($password) || empty($confirm_password)) {
        echo "<script>alert('All fields are required.');</script>";
    } elseif ($password !== $confirm_password) {
        echo "<script>alert('Passwords do not match.');</script>";
    } else {
        $stmt = $conn->prepare("SELECT * FROM signup WHERE email = :email");
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        
        if ($stmt->rowCount() > 0) {
            echo "<script>alert('Email already exists.');</script>";
        } else {
            try {
                $hashed_password = password_hash($password, PASSWORD_BCRYPT);
                $stmt = $conn->prepare("INSERT INTO signup (first_name, last_name, phone_number, email, password) VALUES (:first_name, :last_name, :phone_number, :email, :password)");
                $stmt->bindParam(':first_name', $first_name);
                $stmt->bindParam(':last_name', $last_name);
                $stmt->bindParam(':phone_number', $phone_number);
                $stmt->bindParam(':email', $email);
                $stmt->bindParam(':password', $hashed_password);
                $stmt->execute();
                echo "<script>alert('Sign up successful! Please login.');</script>";
            } catch (PDOException $e) {
                echo "<script>alert('Error: " . $e->getMessage() . "');</script>";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>2WheelDeal</title>
  <link rel="stylesheet" href="home.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
  
</head>
<Style>
  /* Sign-Up Popup Styling */
#signup-popup {
  display: none;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  justify-content: center;
  align-items: center;
}

#signup-popup .popup-content {
  background: #fff;
  padding: 25px;
  border-radius: 12px;
  width: 350px;
  text-align: center;
  position: relative;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
  animation: fadeIn 0.3s ease-in-out;
}

#signup-popup h2 {
  font-family: 'Montserrat', sans-serif;
  font-size: 22px;
  color: #333;
  margin-bottom: 15px;
}

#signup-popup input {
  width: 100%;
  padding: 10px;
  margin: 8px 0;
  border: 1px solid #ccc;
  border-radius: 5px;
  font-size: 14px;
}

#signup-popup button {
  width: 100%;
  padding: 12px;
  background: #ff6600;
  color: #fff;
  border: none;
  border-radius: 5px;
  font-size: 16px;
  cursor: pointer;
  transition: background 0.3s ease;
}

#signup-popup button:hover {
  background: #e65c00;
}

#signup-popup .close-btn {
  position: absolute;
  top: 10px;
  right: 15px;
  font-size: 20px;
  cursor: pointer;
  color: #333;
}

#signup-popup p {
  margin-top: 12px;
  font-size: 14px;
}

#signup-popup a {
  color: #ff6600;
  text-decoration: none;
  font-weight: bold;
}

#signup-popup a:hover {
  text-decoration: underline;
}

/* Fade-in animation */
@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(-10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

</Style>
<body>
  <!-- Navigation Bar -->
  <nav>
    <div class="logo">2 Wheel Deal</div>
    <ul class="nav-links">
      <li><a href="#">Home</a></li>
      <li><a href="#">Products</a></li>
      <li><a href="#"><i class="fas fa-shopping-cart"></i> Cart</a></li>
      <li><button id="profile-btn"><i class="fas fa-user-circle"></i></button></li>
    </ul>
  </nav>

  <!-- Profile Pop-up -->
  <div id="profile-popup" class="popup">
    <div class="popup-content">
      <span class="close-btn">&times;</span>
      <h2>Welcome Back!</h2>
      <form id="auth-form" method="POST">
        <!-- Login Form -->
        <div id="login-form">
          <input type="email" name="email" placeholder="Email" required>
          <input type="password" name="password" placeholder="Password" required>
          <button type="submit" name="login">Login</button>
        </div>
      </form>
      <p class="create-account">Don't have an account? <a href="#" id="signup-link">Create Account</a></p>
    </div>
  </div>

  <!-- Sign-Up Pop-up -->
  <div id="signup-popup" class="popup">
    <div class="popup-content">
      <span class="close-btn">&times;</span>
      <h2>Create an Account</h2>
      <form id="signup-form" method="POST">
        <input type="text" name="first_name" placeholder="First Name" required>
        <input type="text" name="last_name" placeholder="Last Name" required>
        <input type="tel" name="phone_number" placeholder="Phone Number" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>
        <input type="password" name="confirm_password" placeholder="Confirm Password" required>
        <button type="submit" name="signup">Sign Up</button>
      </form>
      <p class="create-account">Already have an account? <a href="#" id="login-link">Login</a></p>
    </div>
  </div>

  <!-- Home Page Content -->
  <section class="hero">
    <h1>Welcome to 2 Wheel Deal</h1>
    <p>Motorcycle Dealership</p>
    <p>From high-performance sports bike to precision-engineered machines,<br> we help you push the limits. Browse our collection and take your riding to the next level.</p>
    <a href="products.php" class="btn">Shop Now</a>
  </section>

  <!-- Footer -->
  <footer>
    <p>&copy; 2025 2WheelDeal. All rights reserved.</p>
  </footer>

  <script>
    // Open Profile Pop-up
    document.getElementById('profile-btn').addEventListener('click', function() {
      document.getElementById('profile-popup').style.display = 'flex';
    });

    // Close Profile Pop-up
    document.querySelector('.close-btn').addEventListener('click', function() {
      document.getElementById('profile-popup').style.display = 'none';
      document.getElementById('signup-popup').style.display = 'none';
    });

    // Close Pop-up when clicking outside
    window.addEventListener('click', function(event) {
      if (event.target === document.getElementById('profile-popup') || event.target === document.getElementById('signup-popup')) {
        document.getElementById('profile-popup').style.display = 'none';
        document.getElementById('signup-popup').style.display = 'none';
      }
    });

    // Switch to Sign-up Form
    document.getElementById('signup-link').addEventListener('click', function(event) {
      event.preventDefault();
      document.getElementById('profile-popup').style.display = 'none';
      document.getElementById('signup-popup').style.display = 'flex';
    });

    // Switch back to Login Form
    document.getElementById('login-link').addEventListener('click', function(event) {
      event.preventDefault();
      document.getElementById('signup-popup').style.display = 'none';
      document.getElementById('profile-popup').style.display = 'flex';
    });
  </script>
</body>
</html>