<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

$host = "localhost";
$user = "root";  // Change if necessary
$password = "";  // Change if necessary
$dbname = "coffee_shop";

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die("<script>alert('Connection failed: " . $conn->connect_error . "');</script>");
}
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["login-email"])) {
    $email = $_POST["login-email"];
    $password = $_POST["login-password"];

    $stmt = $conn->prepare("SELECT id, first_name, password FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id, $first_name, $hashed_password);
        $stmt->fetch();

        if (password_verify($password, $hashed_password)) {
            $stmt->fetch();

            // Verify password
            if (password_verify($password, $hashed_password)) {
            $_SESSION["user_id"] = $id;
            $_SESSION["first_name"] = $first_name;
                echo "<script>alert('Login successful. Welcome, $first_name!'); window.location.href='main.php';</script>";
                exit();
            } else {
                echo "<script>alert('Invalid email or password.'); window.location.href='notmain.php';</script>";
            }
        } else {
            echo "<script>alert('User not found.'); window.location.href='notmain.php';</script>";
        }

        $stmt->close();
    } else {
        // Signup logic
        $first_name = $_POST["first_name"] ?? '';
        $last_name = $_POST["last_name"] ?? '';
        $phone = $_POST["phone"] ?? '';
        $email = $_POST["email"] ?? '';
        $password = $_POST["password"] ?? '';
        $confirm_password = $_POST["confirm-password"] ?? '';

        // Validate password and confirm password
        if ($password !== $confirm_password) {
            echo "<script>alert('Password and Confirm Password do not match.'); window.location.href='notmain.php';</script>";
            exit(); // Stop further execution
        }

        // Hash the password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Check if email or phone exists
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? OR phone = ?");
        $stmt->bind_param("ss", $email, $phone);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            echo "<script>alert('Email or Phone already exists.'); window.location.href='notmain.php';</script>";
        } else {
            $stmt = $conn->prepare("INSERT INTO users (first_name, last_name, phone, email, password) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("sssss", $first_name, $last_name, $phone, $email, $hashed_password);
            if ($stmt->execute()) {
                echo "<script>alert('Registration successful.'); window.location.href='notmain.php';</script>";
            } else {
                echo "<script>alert('Error registering user.'); window.location.href='notmain.php';</script>";
            }
        }
        $stmt->close();
    }
    $conn->close();
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complete Responsive Coffee Shop Website Design</title>

    <!-- Font Awesome CDN Link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- Custom CSS File Link -->
    <link rel="stylesheet" href="style.css">
</head>
<style>
   /* Ensure popup is centered */
.login-popup {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.7);
    display: none;
    justify-content: center;
    align-items: center;
    z-index: 1000;
}

.popup-content {
    background: rgba(34, 28, 24, 0.95);
    padding: 30px;
    border-radius: 10px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
    width: 90%; /* Adjust width for smaller screens */
    max-width: 500px;
    text-align: center;
    position: relative;
    max-height: 80vh; /* Limits height to 80% of the viewport */
    overflow-y: auto; /* Enables scrolling if content exceeds max-height */
}

/* Ensure scrollbar is styled for better UX */
.popup-content::-webkit-scrollbar {
    width: 6px;
}

.popup-content::-webkit-scrollbar-thumb {
    background: #c49a6c;
    border-radius: 10px;
}

.popup-content::-webkit-scrollbar-track {
    background: rgba(34, 28, 24, 0.5);
}


.close-popup {
    position: absolute;
    top: 10px;
    right: 15px;
    font-size: 20px;
    cursor: pointer;
    color: white;
}

h2 {
    margin-bottom: 20px;
    font-size: 24px;
    color: white;
}

.form-group {
    text-align: left;
    font-size: 14px;
    margin-bottom: 15px;
}

input {
    width: 100%;
    padding: 12px;
    border: none;
    border-radius: 5px;
    background: #2e2a27;
    color: white;
    font-size: 16px;
    box-sizing: border-box;
}

input::placeholder {
    color: #b5a99b;
}

button {
    width: 100%;
    padding: 12px;
    background: #c49a6c;
    border: none;
    color: white;
    font-size: 18px;
    font-weight: bold;
    border-radius: 5px;
    cursor: pointer;
    margin-top: 10px;
    transition: background 0.3s;
}

button:hover {
    background: #a37850;
}

label {
    display: block;
    margin-bottom: 5px;
    color: #b5a99b;
}

/* Grid layout for larger screens */
.grid-container {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 10px;
}

/* Responsive Design */
@media screen and (max-width: 768px) {
    .grid-container {
        grid-template-columns: repeat(2, 1fr); /* 2 columns on tablets */
    }
}

@media screen and (max-width: 480px) {
    .grid-container {
        grid-template-columns: 1fr; /* Single column on small screens */
    }
}

</style>
<body>

    <!-- Header Section Starts -->
    <header class="header">
        <a href="" class="logo">
            <img src="images/logo.png" alt="">
        </a>
        <nav class="navbar">
            <a href="#home">Home</a>
            <a href="#about">About</a>
            <a href="#menu">Menu</a>
            <a href="#products">Products</a>
            <a href="#contact">Contact</a>
            <a href="#" id="trigger-login">Login</a>
        </nav>
        <div class="icons">
            <div class="fas fa-search" id="search-btn"></div>
            <div class="fas fa-shopping-cart open-cart" id="cart-btn">
                <span class="cart-item-total"></span>
            </div>
            <div class="fas fa-bars" id="bars-btn"></div>
        </div>
        
    </header>
    <!-- Header Section Ends -->

    <!-- Home Section Starts -->
    <section class="home" id="home">
        <div class="content">
            <h3>Fresh Coffee in the Morning</h3>
            <p>Start your day with the perfect cup of coffee. Join our community of coffee lovers and discover rich flavors, expert brewing tips, and exclusive deals. Sign up now and make every morning special!.</p>
            <button class="trigger-button" id="trigger-login">Get Yours Now</button>
        </div>
    </section>
    <!-- Home Section Ends -->

    <!-- Login Popup Section -->
   
   <!-- Login and Signup Popup Section -->
<div class="login-popup" id="login-popup">
    <div class="popup-content">
        <span class="close-popup" id="close-popup">&times;</span>
        
        <!-- Login Form -->
       <!-- Login Form -->
<div id="login-form">
    <h2>Welcome Back!</h2>
    <p>Please log in to continue.</p>
    <form method="post">
        <div class="form-group">
            <label for="login-email">Email</label>
            <input type="email" id="login-email" name="login-email" placeholder="Enter your email" required>
        </div>
        <div class="form-group">
            <label for="login-password">Password</label>
            <input type="password" id="login-password" name="login-password" placeholder="Enter your password" required>
        </div>
        <button type="submit">Login</button>
        <p>Don't have an account? <a href="#" id="show-signup">Sign up</a></p>
    </form>
</div>

<!-- Signup Form -->
<div id="signup-form" class="hidden">
    <h2>Join Our Coffee Community</h2>
    <form id="signupForm" method="post">
        <div class="grid-container">
            <div class="form-group">
                <label for="first-name">First Name</label>
                <input type="text" id="first-name" name="first_name" placeholder="First name" required>
            </div>
            <div class="form-group">
                <label for="last-name">Last Name</label>
                <input type="text" id="last-name" name="last_name" placeholder="Last name" required>
            </div>
            <div class="form-group">
                <label for="phone">Phone Number</label>
                <input type="text" id="phone" name="phone" placeholder="Phone number" required>
            </div>
            <div class="form-group">
                <label for="signup-email">Email</label>
                <input type="email" id="signup-email" name="email" placeholder="Email" required>
            </div>
            <div class="form-group">
                <label for="signup-password">Password</label>
                <input type="password" id="signup-password" name="password" placeholder="Password" required>
            </div>
            <div class="form-group">
                <label for="confirm-password">Confirm Password</label>
                <input type="password" id="confirm-password"  name="confirm-password" placeholder="Confirm password" required>
            </div>
        </div>
        <button type="submit">Sign Up</button>
    </form>
    <p id="signup-message"></p>
    <p>Already have an account? <a href="#" id="show-login">Login</a></p>
</div>
    </div>
</div>

<script>
  
  document.getElementById("trigger-login").addEventListener("click", function() {
    document.getElementById("login-popup").style.display = "flex";
    document.getElementById("login-form").style.display = "block";
    document.getElementById("signup-form").style.display = "none";
});

document.getElementById("close-popup").addEventListener("click", function() {
    document.getElementById("login-popup").style.display = "none";
});

document.getElementById("show-signup").addEventListener("click", function() {
    document.getElementById("login-form").style.display = "none";
    document.getElementById("signup-form").style.display = "block";
});

document.getElementById("show-login").addEventListener("click", function() {
    document.getElementById("signup-form").style.display = "none";
    document.getElementById("login-form").style.display = "block";
});
</script>

    <script src="script.js"></script>
</body>

</html>