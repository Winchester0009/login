<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION["user_id"])) {
    header("Location: notmain.php"); // Redirect to login
    exit();
}

// Prevent caching
header("Cache-Control: no-store, no-cache, must-revalidate"); // HTTP 1.1
header("Pragma: no-cache"); // HTTP 1.0
header("Expires: 0"); // Proxies

echo "Welcome, " . $_SESSION["first_name"] . "!";
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>complete responsive coffee shop website design</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="style.css">

</head>

<body>

    <!-- header section starts  -->
    <header class="header">
        <a href="" class="logo">
            <img src="images/logo.png" alt="">
        </a>
        <nav class="navbar">
            <a href="#home">Home</a>
            <a href="#about">About</a>
            <a href="#products">Products</a>
            <a href="#contact">Contact</a>
            <a href="notmain.php">Logout</a>

        </nav>
        <div class="icons">
            <div class="fas fa-search" id="search-btn">
            </div>
            <div class="fas fa-shopping-cart open-cart" id="cart-btn">
                <span class="cart-item-total">0</span>
            </div>
            <div class="fas fa-bars" id="bars-btn"></div>

        </div>
        <div class="search-form">
            <input type="search" id="search-box" placeholder="search here......">
            <label for="search-box" class="fas fa-search"></label>
        </div>

      <!-- <div class="cart-item-container"> -->
            <!-- <div class="cart-item">

                <span class="fa fa-trash"></span>
                <img src="images/cart-item-1.png" alt="">

                <div class="content">
                    <h3>cart item </h3>
                    <div class="price">$123</div>

                </div>
                <div class="count">
                    <span> <i class="fa fa-chevron-up"></i></span>
                    <h3>1</h3>
                    <span> <i class="fa fa-chevron-down"></i></span>
                </div>
            </div> -->
        <!-- <span class="close-cart"><i class="fa fa-times"></i></span>
        <h4 class="total"> total : <span class="totlal-price">$123</span></h4>
        <button class="btn clear">checkOut Now</button>
        </div>  -->
    </header>
    <!-- header section ends -->


    <!-- home section starts  -->
    <section class="home" id="home">
        <div class="content">
            <h3>fresh coffee in the morning </h3>
            <p>Start your day with the perfect cup of coffee. Join our community of coffee lovers and discover rich flavors, expert brewing tips, and exclusive deals. Sign up now and make every morning special!.</p>
            <a href="" class="btn">get yours now</a>

        </div>
    </section>


    <!-- home section ends -->

    <!-- about section starts  -->
    <section class="about" id="about">
        <h1 class="heading"><span>About</span> us</h1>
        <div class="row">
            <div class="image">
                <img src="images/about-img.jpeg" alt="">
            </div>
            <div class="content">
                <h3>Waht makes our coffee spechial ?</h3>
                <p>At our café, we craft each cup with passion, using only the finest, hand-selected coffee beans sourced from the best farms. Our unique roasting process brings out rich flavors and aromatic notes that create a truly unforgettable coffee experience.</p>
                <p>We believe in quality and sustainability, ensuring every sip supports ethical farming practices. Whether you love a bold espresso or a smooth latte, our coffee is made to delight your taste buds.</p>
                <a href="#" class="btn">Learn More</a>
            </div>
        </div>
    </section>


    <!-- about section ends -->

    <!-- menu section starts  

    <section class="menu" id="menu">

        <h1 class="heading">our <span>menu</span></h1>

        <div class="box-container menu-dom">
            <!-- <div class="box">
                <img src="images/menu-1.png" alt="">
                <h3>tasty and healthy </h3>
                <div class="price"> $15.99 <span>$20.99</span> </div>
                <button class="btn "> add to cart</button>
            </div>
            <div class="box">
                <img src="images/menu-2.png" alt="">
                <h3>tasty and healthy </h3>
                <div class="price"> $15.99 <span>$20.99</span> </div>
                <button class="btn "> add to cart</button>
            </div>
            <div class="box">
                <img src="images/menu-3.png" alt="">
                <h3>tasty and healthy </h3>
                <div class="price"> $15.99 <span>$20.99</span> </div>
                <button class="btn "> add to cart</button>
            </div>
            <div class="box">
                <img src="images/menu-4.png" alt="">
                <h3>tasty and healthy </h3>
                <div class="price"> $15.99 <span>$20.99</span> </div>
                <button class="btn "> add to cart</button>
            </div>
            <div class="box">
                <img src="images/menu-5.png" alt="">
                <h3>tasty and healthy </h3>
                <div class="price"> $15.99 <span>$20.99</span> </div>
                <button class="btn "> add to cart</button>
            </div>
            <div class="box">
                <img src="images/menu-6.png" alt="">
                <h3>tasty and healthy </h3>
                <div class="price"> $15.99 <span>$20.99</span> </div>
                <button class="btn "> add to cart</button>
            </div>

        </div>
    </section>
  menu section ends -->
    <!-- products section starts  -->

    <section class="products" id="products">

        <h1 class="heading">our <span>products</span></h1>
        <div class="box-container productDom">
            <div class="box">
                <div class="icons">
                    <a class="fas fa-shopping-cart"></a>
                    <a class="fas fa-heart"></a>
                    <a class="fas fa-eye"></a>

                </div>
                <div class="image">
                    <img src="images/product-1.png" alt="">
                </div>
                <div class="content">
                    <h3>frehs coffee</h3>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>

                    </div>
                    <div class="price"> $15.99 <span>$20.99</span> </div>

                </div>
            </div>
            <div class="box">
                <div class="icons">
                    <a class="fas fa-shopping-cart"></a>
                    <a class="fas fa-heart"></a>
                    <a class="fas fa-eye"></a>

                </div>
                <div class="image">
                    <img src="images/product-2.png" alt="">
                </div>
                <div class="content">
                    <h3>frehs coffee</h3>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>

                    </div>
                    <div class="price"> $15.99 <span>$20.99</span> </div>

                </div>
            </div>
            <div class="box">
                <div class="icons">
                    <a class="fas fa-shopping-cart"></a>
                    <a class="fas fa-heart"></a>
                    <a class="fas fa-eye"></a>

                </div>
                <div class="image">
                    <img src="images/product-3.png" alt="">
                </div>
                <div class="content">
                    <h3>frehs coffee</h3>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>

                    </div>
                    <div class="price"> $15.99 <span>$20.99</span> </div>

                </div>
            </div> 

        </div>

    </section>
    <!-- products section ends 
     review section starts  
    <section class="review" id="review">

        <h1 class="heading">customer's <span>review</span></h1>
        <div class="box-container">
            <div class="box">
                <img src="images/quote-img.png" class="quote" alt="">
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eius quam aliquam quas obcaecati! Delectus
                    repellendus nam ratione incidunt recusandae ipsum minima! Iusto libero aliquam harum doloremque
                    nulla, hic excepturi vel?</p>

                <img src="images/pic-1.png" class="user" alt="">
                <h3>joan deo</h3>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>

                </div>

            </div>
            <div class="box">
                <img src="images/quote-img.png" class="quote" alt="">
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eius quam aliquam quas obcaecati! Delectus
                    repellendus nam ratione incidunt recusandae ipsum minima! Iusto libero aliquam harum doloremque
                    nulla, hic excepturi vel?</p>
                <img src="images/pic-2.png" class="user" alt="">
                <h3>joan deo</h3>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>

                </div>

            </div>
            <div class="box">
                <img src="images/quote-img.png" class="quote" alt="">
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eius quam aliquam quas obcaecati! Delectus
                    repellendus nam ratione incidunt recusandae ipsum minima! Iusto libero aliquam harum doloremque
                    nulla, hic excepturi vel?</p>

                <img src="images/pic-3.png" class="user" alt="">
                <h3>joan deo</h3>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>

                </div>

            </div>
        </div>

    </section>

     review section ends -->

    <!-- contact section starts  -->
    <section class="contact" id="contact">

        <h1 class="heading">contact <span>us</span></h1>
        <div class="row">
        
            <form action="">
                <h3>get in touch</h3>
                <div class="inputBox">
                    <span class="fas fa-user"></span>
                    <input type="text" placeholder="Name">
                </div>
                <div class="inputBox">
                    <span class="fas fa-envelope"></span>
                    <input type="email" placeholder="Email">
                </div>
                <div class="inputBox">
                    <span class="fas fa-phone"></span>
                    <input type="phone" placeholder="phone">
                </div>
                <input type="submit" value="contact Now" class="btn">
            </form>
        </div>

    </section>


    <!-- contact section ends 

     blogs section starts 
    <section class="blogs" id="blogs">

        <h1 class="heading">our <span>blogs</span></h1>

        <div class="box-container">
            <div class="box">
                <div class="image">
                    <img src="images/blog-1.jpeg" alt="">
                </div>
                <div class="content">
                    <a href="" class="title">tasty and refreshing coffee</a>
                    <span>by admin / 21st may , 2021</span>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Deserunt, hic.</p>
                    <a href="" class="btn">Read More</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="images/blog-2.jpeg" alt="">
                </div>
                <div class="content">
                    <a href="" class="title">tasty and refreshing coffee</a>
                    <span>by admin / 21st may , 2021</span>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Deserunt, hic.</p>
                    <a href="" class="btn">Read More</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="images/blog-3.jpeg" alt="">
                </div>
                <div class="content">
                    <a href="" class="title">tasty and refreshing coffee</a>
                    <span>by admin / 21st may , 2021</span>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Deserunt, hic.</p>
                    <a href="" class="btn">Read More</a>
                </div>
            </div>
        </div>

    </section>

    blogs section ends -->

    <!-- footer section starts  -->
    <section class="footer">
        <div class="share">
            <a href="" class="fab fa-facebook-f"></a>
            <a href="" class="fab fa-instagram"></a>
        </div>

        <div class="links">
            <a href="#home">Home</a>
            <a href="#about">About</a>
            <a href="#products">Products</a>
            <a href="#contact">Contact</a>


        </div>
        <div class="cradit">
            created By <span>Arthun ka Talagaa</span> | All Rights Reseved
        </div>
    </section>
    <!-- footer section ends -->

    <section class="cart__overlay">
        <div class="cart">
          <span class="close__cart">
            <i class="fa fa-times"></i>
          </span>
          <h1>Your Cart</h1>
          <div class="cart__centent">
            <!-- Cart Item -->
            <!-- <div class="cart__item">
              <img src="./images/menu-1.png" alt="">
              <div>
                <h3>tasty and healthy</h3>
                <h3 class="price">$750</h3>
              </div>
              <div>
                <span class="increase"> <i class="fa fa-chevron-up"></i></span>

                <p>3</p>
                <span class="decrease"> <i class="fa fa-chevron-down"></i></span>

              </div>
    
              <div>
                <span class="remove__item">
                 <i  class="fa fa-trash"></i>
                </span>
              </div>
            </div>  -->
            
          </div>
    
          <div class="cart__footer">
            <h3>Total: $ <span class="cart__total">0</span></h3>
            <button class="clear__cart btn">Clear Cart</button>
          </div>
        </div>
      </section>
    














    <!-- custom js file link  -->
    <script src="script.js"></script>

</body>

</html>

<!-- CREATE DATABASE coffee_shop;

USE coffee_shop;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    phone VARCHAR(15) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL
); -->
